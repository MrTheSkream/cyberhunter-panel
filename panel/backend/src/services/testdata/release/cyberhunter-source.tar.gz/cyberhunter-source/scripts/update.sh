#!/usr/bin/env bash
echo fixture update.sh
